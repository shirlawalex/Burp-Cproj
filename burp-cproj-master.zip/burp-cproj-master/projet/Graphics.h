#pragma once

const char* HEART1 = \
"  _   _   " \
"/   V   \\ " \
" \\     /  " \
"   \\ /    " \
"    *     ";


const char* HEART2= \
" _  _ \n" \
"( `' )\n" \
" `.,' \n";


const char * ROBOT=\
"    ---\n" \
"   | o |\n"\
"   \\___/\n";
