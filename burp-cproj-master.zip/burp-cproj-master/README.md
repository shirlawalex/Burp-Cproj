# Burp-CProj

Projet du cours Cproj

tester le projet avec un affhichage terminal
$ make clean
$ make mrproper
$  gcc projet/mainTerminal.c -o mainTerminal -g `pkg-config glib-2.0 --cflags --libs` -lm
$  ./mainTerminal script/Script3 script/Script3 script/Script3 script/Script3
